import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).parent.parent
TUI = (ROOT / "bench-client" / "vstl-imaging-tui.py").read_text(encoding="utf-8")
EXPORTER = (ROOT / "reporting" / "export_reports.py").read_text(encoding="utf-8")
STATE_API = (ROOT / "reporting" / "bench-state.php").read_text(encoding="utf-8")
REPORT_INSTALLER = (ROOT / "07_install_reporting.sh").read_text(encoding="utf-8")


def load_tui_functions(*names):
    tree = ast.parse(TUI)
    selected = [
        node for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in names
    ]
    namespace = {"json": json, "hashlib": hashlib}
    exec(compile(ast.Module(body=selected, type_ignores=[]), "vstl-imaging-tui.py", "exec"), namespace)
    return namespace


def test_bench_has_vstl360_login_contract_endpoints():
    assert '"/imaging/auth/login-pin"' in TUI
    assert '"/imaging/auth/me"' in TUI
    assert '"/imaging/auth/logout"' in TUI
    assert '"X-API-Key"' in TUI
    assert '"Authorization": f"Bearer {operator_token}"' in TUI
    assert 'base = f"{base}/api"' in TUI
    assert '"pin": pin' in TUI
    assert 'body["layer"] = layer' in TUI
    assert 'data.get("need_layer")' in TUI
    assert 'session.get("available_layers")' in TUI
    login_fn = TUI[TUI.index("def auth_login_pin("):TUI.index("def auth_me(")]
    assert '"email": email' not in login_fn
    assert '"password": password' not in login_fn


def test_login_controls_layer_before_bench_screen_access():
    login_pos = TUI.index("operator = screen_login(stdscr, cfg)")
    layer_pos = TUI.index("selected_layer = screen_working_layer(stdscr, _operator_name(operator))")
    tech_pos = TUI.index("tech = _operator_technician_level(operator)")
    menu_pos = TUI.index("choice = screen_main_menu(stdscr, tech, operator)")
    assert login_pos < layer_pos < tech_pos < menu_pos
    assert "Login is required before L1/L2 bench access." in TUI
    assert "Enter your 4-digit Imaging PIN:" in TUI
    assert "PIN must be exactly 4 digits" in TUI
    assert "PIN login is once per shift" in TUI
    assert "L1 and L2 users may select either L1 or L2." in TUI
    assert "there is no local override" not in TUI
    technician_fn = TUI[TUI.index("def screen_technician("):TUI.index("MENU_OPTIONS =")]
    assert "Select your technician level" not in technician_fn


def test_capture_option_is_admin_or_capture_permission_only_on_bench_menu():
    assert "def _visible_menu_options(operator" in TUI
    assert "if not _operator_has_capture_access(operator):" in TUI
    assert "if idx != 3" in TUI
    assert "Capture is hidden because this user is not Admin and has no Capture access permission." in TUI
    ns = load_tui_functions(
        "_operator_user",
        "_operator_roles",
        "_truthy_operator_value",
        "_operator_is_admin",
        "_operator_permissions",
        "_normalize_permission",
        "_operator_has_capture_access",
    )
    assert ns["_operator_has_capture_access"]({"user": {"is_admin": True}})
    assert ns["_operator_has_capture_access"]({"user": {"capture_access": True}})
    assert ns["_operator_has_capture_access"]({"user": {"permissions": ["imaging.capture"]}})
    assert ns["_operator_has_capture_access"]({"user": {"roles": ["Capture Access"]}})
    assert not ns["_operator_has_capture_access"]({"user": {"roles": ["Layer 2"]}})


def test_logged_in_user_is_attached_to_payload_and_reports():
    assert "def _attach_operator_to_payload" in TUI
    assert 'payload["user"] = name' in TUI
    assert 'payload["technician_user_name"] = name' in TUI
    assert '_attach_operator_to_payload(payload, operator)' in TUI
    assert '"User"' in EXPORTER
    assert 'payload.get("technician_user_name")' in EXPORTER


def test_shift_session_is_cached_on_the_imaging_server():
    assert '"GET", "session"' in TUI
    assert '"POST",\n            "session"' in TUI
    assert '"DELETE", "session"' in TUI
    assert "bench-state.php" in TUI
    assert "bench-state.php" in REPORT_INSTALLER
    assert "hash('sha256', $benchId)" in STATE_API
    assert "'token' => (string)$session['token']" in STATE_API


def test_completed_units_use_operator_owned_durable_retry_queue():
    assert "def _queue_pending_ingest(" in TUI
    assert "def flush_pending_ingests(" in TUI
    assert '"operator_user_id"' in TUI
    assert 'payload["bench_submission_id"]' in TUI
    assert '"POST",\n        "queue"' in TUI
    assert '"DELETE",\n        "queue"' in TUI
    assert "post_ingest(payload, cfg, operator)" in TUI
    assert "operator_user_id" in STATE_API
    assert "submission_id" in STATE_API


def test_local_report_uses_api_key_fallback_and_is_non_blocking_when_cloud_saved():
    assert 'token = cfg.get("VSTL_REPORT_TOKEN") or cfg.get("VSTL_API_KEY", "")' in TUI
    assert "local report token unavailable; cloud audit still uses VSTL_API_KEY" in TUI
    completion_fn = TUI[TUI.index("def screen_completion("):TUI.index("# ---------------------------------------------------------------------------\n# Main controller")]
    assert "cloud_saved = bool(ingest_ok)" in completion_fn
    assert "✅  Cloud audit submitted" in completion_fn
    assert 'local_report_status = "saved" if local_report_ok else "warning"' in completion_fn
    assert "Server report save failed" not in completion_fn


def test_ingest_response_surfaces_reconcile_and_l1_status():
    assert "Not in this box - flagged for reconcile" in TUI
    assert "Imaged into" in TUI
    assert "official L1 audit completed" in TUI
    assert "asset matched by" in TUI
    assert "operator session expired; audit queued safely" in TUI


def test_l1_box_picker_is_wired_before_menu_and_payload_ingest():
    assert '"/imaging/my-boxes"' in TUI
    fetch_fn = TUI[TUI.index("def fetch_my_boxes("):TUI.index("def auth_logout(")]
    assert "token=token" in fetch_fn
    assert "include_key=True" not in fetch_fn

    tech_pos = TUI.index("tech = _operator_technician_level(operator)")
    box_pos = TUI.index('if tech == "L1" and not ensure_operator_box(stdscr, cfg, operator):')
    menu_pos = TUI.index("choice = screen_main_menu(stdscr, tech, operator)")
    assert tech_pos < box_pos < menu_pos
    assert "if choice != BOX_SWITCH_CHOICE:" in TUI
    assert "screen_box_picker(stdscr, cfg, operator)" in TUI
    assert "_attach_box_scope_to_payload(payload, operator)" in TUI


def test_box_scope_attaches_only_to_l1_payloads_and_tracks_slot_fill():
    ns = load_tui_functions(
        "_operator_user",
        "_operator_roles",
        "_normalize_layer",
        "_operator_layer",
        "_operator_technician_level",
        "_nonnegative_int",
        "_normalize_box_scope",
        "_operator_box",
        "_attach_box_scope_to_payload",
    )
    box = {
        "lot_no": "LOT-2206",
        "box_no": "BOX NO 01",
        "total": 20,
        "remaining": 13,
        "imaged": 7,
    }
    l1_payload = {}
    ns["_attach_box_scope_to_payload"](
        l1_payload,
        {"selected_layer": "Layer 1", "selected_box": box, "user": {}},
    )
    assert l1_payload["lot_no"] == "LOT-2206"
    assert l1_payload["box_no"] == "BOX NO 01"
    assert l1_payload["raw_data"]["box_scope"]["remaining"] == 13

    l2_payload = {}
    ns["_attach_box_scope_to_payload"](
        l2_payload,
        {"selected_layer": "Layer 2", "selected_box": box, "user": {}},
    )
    assert "lot_no" not in l2_payload
    assert "box_no" not in l2_payload

    assert 'if data.get("slot_filled"):' in TUI
    assert "_decrement_operator_box(operator, cfg)" in TUI


def test_box_slot_fill_and_reconcile_responses_are_operator_readable():
    ns = load_tui_functions(
        "_nonnegative_int",
        "_normalize_box_scope",
        "_format_ingest_response",
    )
    payload = {"lot_no": "LOT-2206", "box_no": "BOX NO 01"}
    filled = ns["_format_ingest_response"](
        {"slot_filled": True, "l1_completed": True}, payload
    )
    assert filled == "Imaged into LOT-2206 / BOX NO 01 - L1 complete"

    overflow = ns["_format_ingest_response"](
        {"asset_created": True, "match_method": "bench_created"}, payload
    )
    assert overflow.startswith("WARNING: Not in this box - flagged for reconcile")


def test_layer_normalization_prefers_local_bench_selection_over_cloud_layer():
    ns = load_tui_functions(
        "_operator_user",
        "_operator_roles",
        "_normalize_layer",
        "_operator_layer",
        "_operator_technician_level",
    )
    assert ns["_normalize_layer"]("L1") == "Layer 1"
    assert ns["_normalize_layer"]("layer_2") == "Layer 2"
    assert ns["_operator_technician_level"](
        {"selected_layer": "Layer 1", "user": {"layer": "Layer 2", "roles": ["Layer 2"]}}
    ) == "L1"
    assert ns["_operator_technician_level"](
        {"selected_layer": "L2", "user": {"layer": "Layer 1", "roles": ["Layer 1"]}}
    ) == "L2"
    assert ns["_operator_technician_level"]({"user": {"layer": "Layer 2"}}) == "L2"
    assert ns["_operator_technician_level"]({"user": {"roles": ["Layer 1"]}}) == "L1"
    assert ns["_operator_technician_level"](
        {"user": {"roles": ["Layer 1", "Layer 2"]}}
    ) == ""


def test_login_pin_handles_need_layer_and_persists_selected_layer():
    ns = load_tui_functions(
        "_bench_id",
        "_normalize_layer",
        "_auth_session_from_response",
        "auth_login_pin",
    )
    saved = []
    ns["_save_auth_session"] = lambda session, cfg: saved.append((session, cfg))
    ns["_auth_request"] = lambda *args, **kwargs: (
        True,
        {
            "ok": False,
            "need_layer": True,
            "available_layers": ["Layer 1", "Layer 2"],
            "operator_name": "Rahul",
        },
        "ok",
        200,
    )
    ok, response, message = ns["auth_login_pin"]({"BENCH_ID": "B1"}, "0427")
    assert not ok
    assert response["need_layer"] is True
    assert "layer" in message

    ns["_auth_request"] = lambda *args, **kwargs: (
        True,
        {
            "ok": True,
            "token": "jwt",
            "selected_layer": "Layer 2",
            "user": {"id": "u1", "name": "Rahul", "roles": ["Layer 1", "Layer 2"]},
        },
        "ok",
        200,
    )
    ok, session, _message = ns["auth_login_pin"]({"BENCH_ID": "B1"}, "0427", "Layer 2")
    assert ok
    assert session["selected_layer"] == "Layer 2"
    assert session["user"]["layer"] == "Layer 2"
    assert saved[-1][0]["token"] == "jwt"


def test_pin_login_repairs_bad_rtc_on_tls_certificate_verify_failure():
    assert "import ssl" in TUI
    assert "from email.utils import parsedate_to_datetime" in TUI
    assert "def _repair_clock_after_cert_error(" in TUI
    assert 'method="HEAD"' in TUI
    assert '"Date"' in TUI
    assert '["date", "-u", "-s", f"@{epoch}"]' in TUI
    assert "ssl._create_unverified_context()" in TUI
    auth_fn = TUI[TUI.index("def _auth_request("):TUI.index("def _auth_session_from_response(")]
    assert "_certificate_verify_failed(e) and _repair_clock_after_cert_error(cfg)" in auth_fn
    assert "Authorization" not in TUI[
        TUI.index("def _read_server_http_date_epoch("):TUI.index("def _set_system_clock_utc(")
    ]
